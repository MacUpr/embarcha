/**
 * Projeto: Servidor HTTP com controle de LED e leitura de temperatura - Raspberry Pi Pico W
 *
 * Objetivos:
 * - Configurar o Raspberry Pi Pico W como um ponto de acesso (Access Point) Wi-Fi.
 * - Iniciar servidores DHCP e DNS locais para permitir a conexão de dispositivos clientes.
 * - Criar um servidor HTTP embarcado que disponibiliza uma página HTML de controle.
 * - Permitir o controle remoto de um LED conectado ao GPIO 13 através de comandos HTTP.
 * - Exibir a temperatura interna do microcontrolador RP2040 na interface web.
 * - Fornecer mensagens de depuração no terminal USB.
 *
 * Funcionalidades:
 * - Criação de uma rede Wi-Fi com nome (SSID) e senha definidos no código.
 * - Atribuição automática de IP aos dispositivos conectados via servidor DHCP.
 * - Interface HTML que permite visualizar e alterar o estado do LED (ligado/desligado).
 * - Leitura e exibição da temperatura interna do RP2040 via ADC canal 4.
 * - Manipulação direta de pinos GPIO por meio de requisições do navegador.
 * - Debug completo via terminal USB usando pico_stdio_usb.
 * - Finalização controlada do modo Access Point via tecla 'd'.
 */

#include <stdio.h>
#include <string.h>

#include "pico/cyw43_arch.h"
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/gpio.h"

#include "lwip/pbuf.h"
#include "lwip/tcp.h"

#include "dhcpserver.h"
#include "dnsserver.h"

#define TCP_PORT 80
#define DEBUG_printf printf
#define POLL_TIME_S 5
#define HTTP_GET "GET"
#define HTTP_RESPONSE_HEADERS "HTTP/1.1 %d OK\nContent-Length: %d\nContent-Type: text/html; charset=utf-8\nConnection: close\n\n"
#define LED_CONTROL_BODY "<html><head><title>Controle LED e Temperatura</title><style>body{font-family:Arial,sans-serif;margin:40px;background-color:#f0f0f0;}h1{color:#333;text-align:center;}p{font-size:18px;margin:20px 0;}.status{background-color:#fff;padding:20px;border-radius:10px;box-shadow:0 2px 5px rgba(0,0,0,0.1);margin:20px 0;}.button{display:inline-block;padding:15px 30px;margin:10px;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;text-align:center;}.button-on{background-color:#4CAF50;color:white;}.button-off{background-color:#f44336;color:white;}.temp{background-color:#2196F3;color:white;padding:15px;border-radius:5px;text-align:center;font-size:20px;margin:20px 0;}</style></head><body><h1>🔧 Controle do Sistema Embarcado</h1><div class='status'><h2>📊 Status do Sistema</h2><p><strong>LED (GPIO 13):</strong> %s</p><p><strong>🌡️ Temperatura Interna:</strong> <span class='temp'>%.2f °C (%.2f °F)</span></p></div><div class='status'><h2>🎛️ Controles</h2><a href=\"?led=%d\" class=\"button %s\">%s LED</a></div><div class='status'><p><em>Sistema funcionando normalmente. Pressione 'd' no terminal para desativar o Access Point.</em></p></div></body></html>"
#define LED_PARAM "led=%d"
#define LED_CONTROL "/control"
#define LED_GPIO 13
#define ADC_TEMPERATURE_CHANNEL 4
#define HTTP_RESPONSE_REDIRECT "HTTP/1.1 302 Redirect\nLocation: http://%s" LED_CONTROL "\n\n"

typedef struct TCP_SERVER_T_ {
    struct tcp_pcb *server_pcb;
    bool complete;
    ip_addr_t gw;
} TCP_SERVER_T;

typedef struct TCP_CONNECT_STATE_T_ {
    struct tcp_pcb *pcb;
    int sent_len;
    char headers[256];
    char result[2048];  // Aumentado para acomodar HTML mais complexo
    int header_len;
    int result_len;
    ip_addr_t *gw;
} TCP_CONNECT_STATE_T;

// Função para converter o valor lido do ADC para temperatura em graus Celsius
float adc_to_temperature_celsius(uint16_t adc_value) {
    // Constantes fornecidas no datasheet do RP2040
    const float conversion_factor = 3.3f / (1 << 12);  // Conversão de 12 bits (0-4095) para 0-3.3V
    float voltage = adc_value * conversion_factor;     // Converte o valor ADC para tensão
    float temperature_c = 27.0f - (voltage - 0.706f) / 0.001721f;  // Equação fornecida
    return temperature_c;
}

// Função para ler a temperatura interna
float read_internal_temperature() {
    // Seleciona o canal do sensor de temperatura interno
    adc_select_input(ADC_TEMPERATURE_CHANNEL);
    
    // Lê o valor do ADC
    uint16_t adc_value = adc_read();
    
    // Converte para temperatura em Celsius
    float temperature_c = adc_to_temperature_celsius(adc_value);
    
    DEBUG_printf("[DEBUG] ADC Value: %d, Temperature: %.2f °C\n", adc_value, temperature_c);
    
    return temperature_c;
}

static err_t tcp_close_client_connection(TCP_CONNECT_STATE_T *con_state, struct tcp_pcb *client_pcb, err_t close_err) {
    if (client_pcb) {
        assert(con_state && con_state->pcb == client_pcb);
        tcp_arg(client_pcb, NULL);
        tcp_poll(client_pcb, NULL, 0);
        tcp_sent(client_pcb, NULL);
        tcp_recv(client_pcb, NULL);
        tcp_err(client_pcb, NULL);
        err_t err = tcp_close(client_pcb);
        if (err != ERR_OK) {
            DEBUG_printf("[DEBUG] Close failed %d, calling abort\n", err);
            tcp_abort(client_pcb);
            close_err = ERR_ABRT;
        }
        if (con_state) {
            free(con_state);
        }
    }
    return close_err;
}

static void tcp_server_close(TCP_SERVER_T *state) {
    if (state->server_pcb) {
        tcp_arg(state->server_pcb, NULL);
        tcp_close(state->server_pcb);
        state->server_pcb = NULL;
        DEBUG_printf("[DEBUG] TCP server closed\n");
    }
}

static err_t tcp_server_sent(void *arg, struct tcp_pcb *pcb, u16_t len) {
    TCP_CONNECT_STATE_T *con_state = (TCP_CONNECT_STATE_T*)arg;
    DEBUG_printf("[DEBUG] TCP server sent %u bytes\n", len);
    con_state->sent_len += len;
    if (con_state->sent_len >= con_state->header_len + con_state->result_len) {
        DEBUG_printf("[DEBUG] All data sent, closing connection\n");
        return tcp_close_client_connection(con_state, pcb, ERR_OK);
    }
    return ERR_OK;
}

static int generate_control_page(const char *request, const char *params, char *result, size_t max_result_len) {
    int len = 0;
    if (strncmp(request, LED_CONTROL, sizeof(LED_CONTROL) - 1) == 0) {
        // Lê o estado atual do LED
        bool led_state = gpio_get(LED_GPIO);
        
        // Verifica se o usuário quer alterar o estado do LED
        if (params) {
            int new_led_state;
            int parsed = sscanf(params, LED_PARAM, &new_led_state);
            if (parsed == 1) {
                led_state = (new_led_state != 0);
                gpio_put(LED_GPIO, led_state);
                DEBUG_printf("[DEBUG] LED state changed to: %s\n", led_state ? "ON" : "OFF");
            }
        }
        
        // Lê a temperatura interna
        float temp_celsius = read_internal_temperature();
        float temp_fahrenheit = temp_celsius * 1.8f + 32.0f;
        
        // Gera a página HTML com snprintf
        const char *led_status = led_state ? "🟢 LIGADO" : "🔴 DESLIGADO";
        const char *button_class = led_state ? "button-off" : "button-on";
        const char *button_text = led_state ? "DESLIGAR" : "LIGAR";
        int next_state = led_state ? 0 : 1;
        
        len = snprintf(result, max_result_len, LED_CONTROL_BODY, 
                      led_status, 
                      temp_celsius, temp_fahrenheit,
                      next_state, button_class, button_text);
                      
        DEBUG_printf("[DEBUG] Generated page: LED=%s, Temp=%.2f°C\n", 
                    led_state ? "ON" : "OFF", temp_celsius);
    }
    return len;
}

err_t tcp_server_recv(void *arg, struct tcp_pcb *pcb, struct pbuf *p, err_t err) {
    TCP_CONNECT_STATE_T *con_state = (TCP_CONNECT_STATE_T*)arg;
    if (!p) {
        DEBUG_printf("[DEBUG] Connection closed by client\n");
        return tcp_close_client_connection(con_state, pcb, ERR_OK);
    }
    
    assert(con_state && con_state->pcb == pcb);
    if (p->tot_len > 0) {
        DEBUG_printf("[DEBUG] Received %d bytes, err %d\n", p->tot_len, err);
        
        // Copia a requisição para o buffer
        pbuf_copy_partial(p, con_state->headers, 
                         p->tot_len > sizeof(con_state->headers) - 1 ? 
                         sizeof(con_state->headers) - 1 : p->tot_len, 0);

        // Processa requisição GET
        if (strncmp(HTTP_GET, con_state->headers, sizeof(HTTP_GET) - 1) == 0) {
            char *request = con_state->headers + sizeof(HTTP_GET); // + espaço
            char *params = strchr(request, '?');
            if (params) {
                if (*params) {
                    char *space = strchr(request, ' ');
                    *params++ = 0;
                    if (space) {
                        *space = 0;
                    }
                } else {
                    params = NULL;
                }
            }

            // Gera o conteúdo da página
            con_state->result_len = generate_control_page(request, params, 
                                                        con_state->result, 
                                                        sizeof(con_state->result));
            
            DEBUG_printf("[DEBUG] Request: %s?%s\n", request, params ? params : "");
            DEBUG_printf("[DEBUG] Result length: %d\n", con_state->result_len);

            // Verifica se temos espaço suficiente no buffer
            if (con_state->result_len > sizeof(con_state->result) - 1) {
                DEBUG_printf("[ERROR] Too much result data %d\n", con_state->result_len);
                return tcp_close_client_connection(con_state, pcb, ERR_CLSD);
            }

            // Gera a resposta HTTP
            if (con_state->result_len > 0) {
                con_state->header_len = snprintf(con_state->headers, sizeof(con_state->headers), 
                                               HTTP_RESPONSE_HEADERS, 200, con_state->result_len);
                if (con_state->header_len > sizeof(con_state->headers) - 1) {
                    DEBUG_printf("[ERROR] Too much header data %d\n", con_state->header_len);
                    return tcp_close_client_connection(con_state, pcb, ERR_CLSD);
                }
            } else {
                // Envia redirecionamento para página principal
                con_state->header_len = snprintf(con_state->headers, sizeof(con_state->headers), 
                                               HTTP_RESPONSE_REDIRECT, ipaddr_ntoa(con_state->gw));
                DEBUG_printf("[DEBUG] Sending redirect %s", con_state->headers);
            }

            // Envia os cabeçalhos HTTP para o cliente usando tcp_write
            con_state->sent_len = 0;
            err_t err = tcp_write(pcb, con_state->headers, con_state->header_len, 0);
            if (err != ERR_OK) {
                DEBUG_printf("[ERROR] Failed to write header data %d\n", err);
                return tcp_close_client_connection(con_state, pcb, err);
            }

            // Envia o corpo da página para o cliente usando tcp_write
            if (con_state->result_len) {
                err = tcp_write(pcb, con_state->result, con_state->result_len, 0);
                if (err != ERR_OK) {
                    DEBUG_printf("[ERROR] Failed to write result data %d\n", err);
                    return tcp_close_client_connection(con_state, pcb, err);
                }
            }
        }
        tcp_recved(pcb, p->tot_len);
    }
    pbuf_free(p);
    return ERR_OK;
}

static err_t tcp_server_poll(void *arg, struct tcp_pcb *pcb) {
    TCP_CONNECT_STATE_T *con_state = (TCP_CONNECT_STATE_T*)arg;
    DEBUG_printf("[DEBUG] TCP server poll - disconnecting client\n");
    return tcp_close_client_connection(con_state, pcb, ERR_OK);
}

static void tcp_server_err(void *arg, err_t err) {
    TCP_CONNECT_STATE_T *con_state = (TCP_CONNECT_STATE_T*)arg;
    if (err != ERR_ABRT) {
        DEBUG_printf("[DEBUG] TCP client error %d\n", err);
        tcp_close_client_connection(con_state, con_state->pcb, err);
    }
}

static err_t tcp_server_accept(void *arg, struct tcp_pcb *client_pcb, err_t err) {
    TCP_SERVER_T *state = (TCP_SERVER_T*)arg;
    if (err != ERR_OK || client_pcb == NULL) {
        DEBUG_printf("[ERROR] Failure in accept\n");
        return ERR_VAL;
    }
    DEBUG_printf("[DEBUG] Client connected\n");

    // Cria o estado para a conexão
    TCP_CONNECT_STATE_T *con_state = calloc(1, sizeof(TCP_CONNECT_STATE_T));
    if (!con_state) {
        DEBUG_printf("[ERROR] Failed to allocate connect state\n");
        return ERR_MEM;
    }
    con_state->pcb = client_pcb;
    con_state->gw = &state->gw;

    // Configura callbacks para a conexão com o cliente
    tcp_arg(client_pcb, con_state);
    tcp_sent(client_pcb, tcp_server_sent);
    tcp_recv(client_pcb, tcp_server_recv);
    tcp_poll(client_pcb, tcp_server_poll, POLL_TIME_S * 2);
    tcp_err(client_pcb, tcp_server_err);

    return ERR_OK;
}

static bool tcp_server_open(void *arg, const char *ap_name) {
    TCP_SERVER_T *state = (TCP_SERVER_T*)arg;
    DEBUG_printf("[DEBUG] Starting HTTP server on port %d\n", TCP_PORT);

    struct tcp_pcb *pcb = tcp_new_ip_type(IPADDR_TYPE_ANY);
    if (!pcb) {
        DEBUG_printf("[ERROR] Failed to create PCB\n");
        return false;
    }

    err_t err = tcp_bind(pcb, IP_ANY_TYPE, TCP_PORT);
    if (err) {
        DEBUG_printf("[ERROR] Failed to bind to port %d\n", TCP_PORT);
        return false;
    }

    state->server_pcb = tcp_listen_with_backlog(pcb, 1);
    if (!state->server_pcb) {
        DEBUG_printf("[ERROR] Failed to listen\n");
        if (pcb) {
            tcp_close(pcb);
        }
        return false;
    }

    tcp_arg(state->server_pcb, state);
    tcp_accept(state->server_pcb, tcp_server_accept);

    printf("\n🌐 Access Point ativo: '%s'\n", ap_name);
    printf("📱 Conecte-se à rede e acesse: http://192.168.4.1/control\n");
    printf("🔧 Controle LED (GPIO 13) e monitore temperatura via navegador\n");
    printf("⚠️  Pressione 'd' para desativar o Access Point\n\n");
    
    return true;
}

void key_pressed_func(void *param) {
    assert(param);
    TCP_SERVER_T *state = (TCP_SERVER_T*)param;
    int key = getchar_timeout_us(0);
    if (key == 'd' || key == 'D') {
        DEBUG_printf("[DEBUG] Disabling Access Point mode\n");
        cyw43_arch_lwip_begin();
        cyw43_arch_disable_ap_mode();
        cyw43_arch_lwip_end();
        state->complete = true;
    }
}

int main() {
    // Inicializa stdio para debug via USB
    stdio_init_all();
    
    printf("\n🚀 Iniciando sistema embarcado...\n");

    TCP_SERVER_T *state = calloc(1, sizeof(TCP_SERVER_T));
    if (!state) {
        DEBUG_printf("[ERROR] Failed to allocate state\n");
        return 1;
    }

    if (cyw43_arch_init()) {
        DEBUG_printf("[ERROR] Failed to initialise CYW43\n");
        return 1;
    }

    // Inicializa o GPIO 13 para controle do LED físico
    gpio_init(LED_GPIO);
    gpio_set_dir(LED_GPIO, GPIO_OUT);
    gpio_put(LED_GPIO, false);  // LED inicialmente desligado
    printf("🔴 LED (GPIO 13) inicializado - Estado: DESLIGADO\n");

    // Inicializa o ADC para leitura da temperatura interna
    adc_init();
    adc_set_temp_sensor_enabled(true);  // Habilita sensor de temperatura interno
    printf("🌡️  Sensor de temperatura interno habilitado (ADC Canal 4)\n");

    // Configura callback para detecção de tecla pressionada
    stdio_set_chars_available_callback(key_pressed_func, state);

    // Configurações da rede Wi-Fi
    const char *ap_name = "PicoW_LED_Temp";
    const char *password = "pico2024";

    printf("📡 Configurando Access Point...\n");
    cyw43_arch_enable_ap_mode(ap_name, password, CYW43_AUTH_WPA2_AES_PSK);

    #if LWIP_IPV6
    #define IP(x) ((x).u_addr.ip4)
    #else
    #define IP(x) (x)
    #endif

    ip4_addr_t mask;
    IP(state->gw).addr = PP_HTONL(CYW43_DEFAULT_IP_AP_ADDRESS);
    IP(mask).addr = PP_HTONL(CYW43_DEFAULT_IP_MASK);

    #undef IP

    // Inicia o servidor DHCP
    dhcp_server_t dhcp_server;
    dhcp_server_init(&dhcp_server, &state->gw, &mask);
    printf("🔧 Servidor DHCP iniciado\n");

    // Inicia o servidor DNS
    dns_server_t dns_server;
    dns_server_init(&dns_server, &state->gw);
    printf("🔧 Servidor DNS iniciado\n");

    // Inicia o servidor HTTP na porta 80
    if (!tcp_server_open(state, ap_name)) {
        DEBUG_printf("[ERROR] Failed to open HTTP server\n");
        return 1;
    }

    state->complete = false;
    printf("✅ Sistema pronto! Aguardando conexões...\n");
    
    while(!state->complete) {
        #if PICO_CYW43_ARCH_POLL
        cyw43_arch_poll();
        cyw43_arch_wait_for_work_until(make_timeout_time_ms(1000));
        #else
        sleep_ms(1000);
        #endif
    }
    
    printf("\n🔄 Finalizando sistema...\n");
    tcp_server_close(state);
    dns_server_deinit(&dns_server);
    dhcp_server_deinit(&dhcp_server);
    cyw43_arch_deinit();
    
    printf("✅ Sistema finalizado com sucesso\n");
    return 0;
}