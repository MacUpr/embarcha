#include <stdio.h>      // Biblioteca padrão de entrada/saída
#include <string.h>     // Para manipulação de strings (strcmp)
#include "pico/stdlib.h" // Biblioteca do SDK do RP2040
#include "tusb.h"       // Biblioteca TinyUSB para comunicação USB

// Definição dos GPIOs para os LEDs e o buzzer da placa BitDogLab
#define LED_VERDE    11  // LED verde na GPIO 11
#define LED_AZUL     12  // LED azul na GPIO 12
#define LED_VERMELHO 13  // LED vermelho na GPIO 13
#define BUZZER       10  // Buzzer na GPIO 10

// Função para apagar todos os LEDs e desativar o buzzer
void apaga_todos_leds_e_buzzer() {
    gpio_put(LED_VERDE, 0);    // Desliga o LED verde
    gpio_put(LED_AZUL, 0);     // Desliga o LED azul
    gpio_put(LED_VERMELHO, 0); // Desliga o LED vermelho
    gpio_put(BUZZER, 0);       // Desativa o buzzer
}

// Função para acender o LED ou acionar o buzzer correspondente ao comando recebido
void aciona_dispositivo(const char* comando) {
    // Compara o comando recebido com as strings esperadas
    if (strcmp(comando, "verde") == 0) {
        gpio_put(LED_VERDE, 1);    // Acende o LED verde
        sleep_ms(1000);            // Mantém aceso por 1 segundo
        gpio_put(LED_VERDE, 0);    // Desliga o LED verde
    } else if (strcmp(comando, "azul") == 0) {
        gpio_put(LED_AZUL, 1);     // Acende o LED azul
        sleep_ms(1000);            // Mantém aceso por 1 segundo
        gpio_put(LED_AZUL, 0);     // Desliga o LED azul
    } else if (strcmp(comando, "vermelho") == 0) {
        gpio_put(LED_VERMELHO, 1); // Acende o LED vermelho
        sleep_ms(1000);            // Mantém aceso por 1 segundo
        gpio_put(LED_VERMELHO, 0); // Desliga o LED vermelho
    } else if (strcmp(comando, "som") == 0) {
        gpio_put(BUZZER, 1);       // Ativa o buzzer
        sleep_ms(1000);            // Mantém ativo por 1 segundo
        gpio_put(BUZZER, 0);       // Desativa o buzzer
    }
}

int main() {
    // Inicializa as funções de entrada/saída padrão do SDK
    stdio_init_all();

    // Configura os GPIOs dos LEDs e do buzzer como saídas
    gpio_init(LED_VERDE);
    gpio_set_dir(LED_VERDE, GPIO_OUT); // Define GPIO 11 como saída
    gpio_init(LED_AZUL);
    gpio_set_dir(LED_AZUL, GPIO_OUT);  // Define GPIO 12 como saída
    gpio_init(LED_VERMELHO);
    gpio_set_dir(LED_VERMELHO, GPIO_OUT); // Define GPIO 13 como saída
    gpio_init(BUZZER);
    gpio_set_dir(BUZZER, GPIO_OUT);    // Define GPIO 10 como saída

    // Inicializa o dispositivo USB com TinyUSB
    tusb_init();

    // Aguarda a conexão do host (computador) ao dispositivo CDC
    while (!tud_cdc_connected()) {
        sleep_ms(100); // Aguarda 100ms entre verificações
    }
    printf("USB conectado!\n"); // Informa no Monitor Serial que o USB foi conectado

    // Buffer para armazenar os dados recebidos via USB
    char buf[64];
    uint32_t count = 0;

    // Loop principal
    while (true) {
        // Verifica se há dados disponíveis na interface CDC
        if (tud_cdc_available()) {
            // Lê os dados recebidos e armazena no buffer (máximo 63 caracteres + terminador)
            count = tud_cdc_read(buf, sizeof(buf) - 1);
            buf[count] = '\0'; // Adiciona terminador nulo ao final da string

            // Remove caracteres de nova linha (\n) ou retorno de carro (\r) do final
            char* end = buf + count;
            while (end > buf && (end[-1] == '\n' || end[-1] == '\r')) {
                end--;
                *end = '\0';
            }

            // Realiza o eco: envia os dados recebidos de volta ao computador
            tud_cdc_write(buf, strlen(buf));
            tud_cdc_write_flush(); // Garante que os dados sejam enviados imediatamente

            // Aciona o LED ou buzzer correspondente ao comando recebido
            aciona_dispositivo(buf);
        }
        // Executa as tarefas necessárias para manter a comunicação USB ativa
        tud_task();
    }

    return 0; // Nunca alcançado, pois o loop é infinito
}