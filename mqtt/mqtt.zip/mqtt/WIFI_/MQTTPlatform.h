#ifndef MQTT_PLATFORM_H
#define MQTT_PLATFORM_H

#include "lwip/sockets.h"  // Pico SDK usa LWIP

#define MQTTCLIENT_PLATFORM_HEADER "WIFI_/MQTTPlatform.h"

#endif
