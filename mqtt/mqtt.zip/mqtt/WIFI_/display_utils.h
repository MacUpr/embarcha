#ifndef DISPLAY_UTILS_H
#define DISPLAY_UTILS_H

void exibir_status_mqtt(const char *texto);

#endif
