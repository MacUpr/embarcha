/**
 * ------------------------------------------------------------
 * Arquivo: main.c
 * Projeto: TempCycleDMA - Melhorias com Timer Sincronizado
 * ------------------------------------------------------------
 * Descrição:
 *     Melhoria do projeto TempCycleDMA original adicionando
 *     sincronização adequada das tarefas utilizando timers.
 *     
 *     Tarefa 1 - Leitura da temperatura via DMA (500ms - Principal)
 *     Tarefa 2 - Exibição da temperatura no OLED (1s)
 *     Tarefa 3 - Análise da tendência da temperatura (1s)
 *     Tarefa 4 - Controle da matriz NeoPixel (1s)
 *     Tarefa 5 - Alarme visual para temperatura baixa (2s)
 *
 * Melhorias implementadas (conforme solicitado):
 *     - repeating_timer_callback para Tarefa 1 (principal)
 *     - add_repeating_timer_ms sincronizado com as demais tarefas  
 *     - Controle de execução baseado em flags
 *     - Mantém estrutura similar ao TempCycleDMA original
 *
 * 
 * ------------------------------------------------------------
 */

#include <stdio.h>
#include "pico/stdlib.h"
//#include "hardware/watchdog.h"  
#include "pico/time.h"

#include "setup.h"
#include "tarefa1_temp.h"
#include "tarefa2_display.h"
#include "tarefa3_tendencia.h"
#include "tarefa4_controla_neopixel.h"
#include "neopixel_driver.h"
#include "testes_cores.h"
#include "pico/stdio_usb.h"

// ========== DECLARAÇÕES GLOBAIS ==========
float media = 0.0;
tendencia_t t ;

// Flags de controle das tarefas
volatile bool flag_tarefa1 = false;
volatile bool flag_tarefa2 = false;
volatile bool flag_tarefa3 = false;
volatile bool flag_tarefa4 = false;
volatile bool flag_tarefa5 = false;

// Contadores para temporização das tarefas
volatile uint32_t contador_tarefa2 = 0;
volatile uint32_t contador_tarefa3 = 0;
volatile uint32_t contador_tarefa4 = 0;
volatile uint32_t contador_tarefa5 = 0;

// Timers para controle das tarefas
struct repeating_timer timer_tarefa1;

// Variáveis para medição de tempo de execução
absolute_time_t ini_tarefa1, fim_tarefa1;
absolute_time_t ini_tarefa2, fim_tarefa2;
absolute_time_t ini_tarefa3, fim_tarefa3;
absolute_time_t ini_tarefa4, fim_tarefa4;
absolute_time_t ini_tarefa5, fim_tarefa5;

// ========== PROTÓTIPOS DAS FUNÇÕES ==========
bool repeating_timer_callback(struct repeating_timer *t);
void executar_tarefa1(void);
void executar_tarefa2(void);
void executar_tarefa3(void);
void executar_tarefa4(void);
void executar_tarefa5(void);
void inicializar_sistema(void);

// ========== CALLBACK DO TIMER PRINCIPAL ==========
/**
 * Callback executado a cada 500ms pela Tarefa 1 (principal)
 * Controla a sincronização de todas as outras tarefas
 */
bool repeating_timer_callback(struct repeating_timer *t) {
    // Tarefa 1 executa a cada callback (500ms)
    flag_tarefa1 = true;
    
    // Incrementa contadores para as outras tarefas
    contador_tarefa2++;
    contador_tarefa3++;
    contador_tarefa4++;
    contador_tarefa5++;
    
    // Tarefa 2: executa a cada 1000ms (2 callbacks)
    if (contador_tarefa2 >= 2) {
        flag_tarefa2 = true;
        contador_tarefa2 = 0;
    }
    
    // Tarefa 3: executa a cada 1000ms (2 callbacks)
    if (contador_tarefa3 >= 2) {
        flag_tarefa3 = true;
        contador_tarefa3 = 0;
    }
    
    // Tarefa 4: executa a cada 1000ms (2 callbacks)
    if (contador_tarefa4 >= 2) {
        flag_tarefa4 = true;
        contador_tarefa4 = 0;
    }
    
    // Tarefa 5: executa a cada 2000ms (4 callbacks)
    if (contador_tarefa5 >= 4) {
        flag_tarefa5 = true;
        contador_tarefa5 = 0;
    }
    
    return true; // Continua o timer
}

// ========== IMPLEMENTAÇÃO DAS TAREFAS ==========

/**
 * Tarefa 1: Leitura da temperatura via DMA (Principal - 500ms)
 */
void executar_tarefa1(void) {
    ini_tarefa1 = get_absolute_time();
    
    // Executa a leitura da temperatura
    media = tarefa1_obter_media_temp(&cfg_temp, DMA_TEMP_CHANNEL);
    
    fim_tarefa1 = get_absolute_time();
    flag_tarefa1 = false;
}

/**
 * Tarefa 2: Exibição da temperatura no OLED (1000ms)
 */
void executar_tarefa2(void) {
    ini_tarefa2 = get_absolute_time();
    
    // Atualiza o display OLED com temperatura e tendência
    tarefa2_exibir_oled(media, t);
    
    fim_tarefa2 = get_absolute_time();
    flag_tarefa2 = false;
}

/**
 * Tarefa 3: Análise da tendência térmica (1000ms)
 */
void executar_tarefa3(void) {
    ini_tarefa3 = get_absolute_time();
    
    // Analisa a tendência da temperatura
    t = tarefa3_analisa_tendencia(media);
    
    fim_tarefa3 = get_absolute_time();
    flag_tarefa3 = false;
}

/**
 * Tarefa 4: Controle da matriz NeoPixel (1000ms)
 */
void executar_tarefa4(void) {
    ini_tarefa4 = get_absolute_time();
    
    // Define cor da matriz baseada na tendência
    tarefa4_matriz_cor_por_tendencia(t);
    
    fim_tarefa4 = get_absolute_time();
    flag_tarefa4 = false;
}

/**
 * Tarefa 5: Alarme visual para temperatura baixa (2000ms)
 */
void executar_tarefa5(void) {
    ini_tarefa5 = get_absolute_time();
    
    // Alarme visual quando temperatura muito baixa
    if (media < 1.0) {
        npSetAll(COR_BRANCA);
        npWrite();
        sleep_ms(100);  // Flash rápido
        npClear();
        npWrite();
    }
    
    fim_tarefa5 = get_absolute_time();
    flag_tarefa5 = false;
}

/**
 * Inicialização do sistema
 */
void inicializar_sistema(void) {
    // Inicializações básicas - mesmo do TempCycleDMA original
    setup(); // ADC, DMA, interrupções, OLED, etc.
    
    // Aguarda conexão USB (opcional para debug)
    // while (!stdio_usb_connected()) {
    //     sleep_ms(100);
    // }
    
    // Configura e inicia o timer principal (Tarefa 1 - 500ms)
    add_repeating_timer_ms(-500, repeating_timer_callback, NULL, &timer_tarefa1);
    
   
    //watchdog_enable(3000, 1);
    
    printf("Sistema inicializado - Executor Cíclico com Timers\n");
    printf("Tarefa 1: 500ms | Tarefas 2,3,4: 1000ms | Tarefa 5: 2000ms\n");
}

/**
 * Exibe estatísticas de desempenho no terminal
 */
void exibir_estatisticas(void) {
    int64_t tempo1_us = absolute_time_diff_us(ini_tarefa1, fim_tarefa1);
    int64_t tempo2_us = absolute_time_diff_us(ini_tarefa2, fim_tarefa2);
    int64_t tempo3_us = absolute_time_diff_us(ini_tarefa3, fim_tarefa3);
    int64_t tempo4_us = absolute_time_diff_us(ini_tarefa4, fim_tarefa4);
    int64_t tempo5_us = absolute_time_diff_us(ini_tarefa5, fim_tarefa5);
    
    printf("Temp: %.2f°C | T1: %.3fms | T2: %.3fms | T3: %.3fms | T4: %.3fms | T5: %.3fms | Tendência: %s\n",
           media,
           tempo1_us / 1000.0,
           tempo2_us / 1000.0,
           tempo3_us / 1000.0,
           tempo4_us / 1000.0,
           tempo5_us / 1000.0,
           tendencia_para_texto(t));
}

// ========== FUNÇÃO PRINCIPAL ==========
int main() {
    // Inicializa todo o sistema
    inicializar_sistema();
    
    // Loop principal - baseado no TempCycleDMA original
    while (true) {
       
        //watchdog_update();
        
        // Executa tarefas conforme flags (controladas pelo timer)
        if (flag_tarefa1) {
            executar_tarefa1();
        }
        
        if (flag_tarefa2) {
            executar_tarefa2();
        }
        
        if (flag_tarefa3) {
            executar_tarefa3();
        }
        
        if (flag_tarefa4) {
            executar_tarefa4();
        }
        
        if (flag_tarefa5) {
            executar_tarefa5();
        }
        
        // Exibe estatísticas no terminal a cada segundo
        static uint32_t ultimo_print = 0;
        uint32_t agora = to_ms_since_boot(get_absolute_time());
        if (agora - ultimo_print >= 1000) {
            exibir_estatisticas();
            ultimo_print = agora;
        }
        
        // Pequeno delay para evitar consumo excessivo de CPU
        sleep_ms(1);
    }
    
    return 0;
}