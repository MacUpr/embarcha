#ifndef DISPLAY_UTILS_H
#define DISPLAY_UTILS_H

#include <stdint.h>

void mostrar_valor_grande(uint8_t *ssd, float valor, int y);

#endif