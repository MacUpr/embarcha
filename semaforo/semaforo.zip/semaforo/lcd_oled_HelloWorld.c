/*
 * Tarefa-SEU1C4-Temporizadores
 * Semáforo de Trânsito Interativo com OLED
 * Fluxo: cada fase (VERMELHO, VERDE, AMARELO) gerencia sua própria contagem e transição.
 * Botão interrompe apenas na fase VERDE, enviando diretamente para AMARELO.
 * O tick de cada fase verifica o estado antes de reagendar, evitando "travamentos".
 */

#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include "hardware/i2c.h"
#include "ssd1306.h"

// Pinos
#define LED_VERMELHO 13
#define LED_VERDE    11
#define BUZZER       10
#define BOTAO_PED    5
#define I2C_SDA      14
#define I2C_SCL      15

// Estados do semáforo
typedef enum { VERMELHO, VERDE, AMARELO } Estado;
static Estado estado_atual = VERMELHO;

// Contadores para cada fase
static int cnt_red;
static int cnt_green;
static int cnt_yellow;

// IDs de alarmes de tick
static alarm_id_t alarm_red_tick;
static alarm_id_t alarm_green_tick;
static alarm_id_t alarm_yellow_tick;

// Buffer e área do OLED
static uint8_t oled_buf[ssd1306_buffer_length];
static struct render_area oled_area;

// Protótipos
void config_hw();
void fase_vermelho();
int64_t tick_vermelho(alarm_id_t, void *);
void fase_verde();
int64_t tick_verde(alarm_id_t, void *);
void fase_amarelo();
int64_t tick_amarelo(alarm_id_t, void *);
void callback_botao(uint, uint32_t);
void update_display(const char *msg, int cnt);
void beep_short();

// Desenha texto escalado
void ssd_draw_scaled(uint8_t *buf, int x, int y, const char *text, int sc) {
    while (*text) {
        for (int dx = 0; dx < sc; dx++)
            for (int dy = 0; dy < sc; dy++)
                ssd1306_draw_char(buf, x + dx, y + dy, *text);
        x += 6 * sc;
        text++;
    }
}

// Atualiza OLED e Serial
void update_display(const char *msg, int cnt) {
    printf("%s%s%d\n", msg, (cnt>0?": ":""), cnt);
    memset(oled_buf, 0, ssd1306_buffer_length);
    int sc = 2;
    int w = strlen(msg) * 6 * sc;
    int x = (ssd1306_width - w) / 2;
    ssd_draw_scaled(oled_buf, x, 10, msg, sc);
    if (cnt > 0) {
        char b[4]; snprintf(b, sizeof(b), "%d", cnt);
        w = strlen(b) * 6 * sc;
        x = (ssd1306_width - w) / 2;
        ssd_draw_scaled(oled_buf, x, 35, b, sc);
    }
    render_on_display(oled_buf, &oled_area);
}

// Bipe curto no buzzer
void beep_short() {
    gpio_put(BUZZER, 1);
    sleep_ms(100);
    gpio_put(BUZZER, 0);
}

// Configuração de hardware e interrupção do botão
void config_hw() {
    stdio_init_all();
    // LEDs
    gpio_init(LED_VERMELHO); gpio_set_dir(LED_VERMELHO, GPIO_OUT);
    gpio_init(LED_VERDE);    gpio_set_dir(LED_VERDE,    GPIO_OUT);
    // Buzzer
    gpio_init(BUZZER);       gpio_set_dir(BUZZER,       GPIO_OUT);
    gpio_put(BUZZER, 0);
    // Botão com pull-up e IRQ
    gpio_init(BOTAO_PED);
    gpio_set_dir(BOTAO_PED, GPIO_IN);
    gpio_pull_up(BOTAO_PED);
    gpio_set_irq_enabled_with_callback(
        BOTAO_PED, GPIO_IRQ_EDGE_FALL, true, callback_botao);
    // I2C e OLED
    i2c_init(i2c1, ssd1306_i2c_clock * 1000);
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);
    ssd1306_init();
    oled_area.start_column = 0;
    oled_area.end_column   = ssd1306_width - 1;
    oled_area.start_page   = 0;
    oled_area.end_page     = ssd1306_n_pages - 1;
    calculate_render_area_buffer_length(&oled_area);
}

// Callback do botão: interrompe apenas no VERDE
void callback_botao(uint gpio, uint32_t events) {
    static absolute_time_t last = {0};
    absolute_time_t now = get_absolute_time();
    if (absolute_time_diff_us(last, now) < 200000) return;
    last = now;
    if (estado_atual == VERDE) {
        // cancela ticks pendentes de verde
        if (alarm_green_tick) { cancel_alarm(alarm_green_tick); alarm_green_tick = 0; }
        fase_amarelo();
    }
}

// Inicia fase VERMELHO
void fase_vermelho() {
    estado_atual = VERMELHO;
    gpio_put(LED_VERDE,    0);
    gpio_put(LED_VERMELHO, 1);
    cnt_red = 10;
    tick_vermelho(0, NULL);
}

// Tick de VERMELHO: contagem e transição
int64_t tick_vermelho(alarm_id_t id, void *ud) {
    if (estado_atual != VERMELHO) return 0;
    if (cnt_red > 0) {
        update_display("Sinal: Vermelho", cnt_red);
        cnt_red--;
        alarm_red_tick = add_alarm_in_ms(1000, tick_vermelho, NULL, false);
    } else {
        fase_verde();
    }
    return 0;
}

// Inicia fase VERDE
void fase_verde() {
    estado_atual = VERDE;
    gpio_put(LED_VERMELHO, 0);
    gpio_put(LED_VERDE,    1);
    cnt_green = 10;
    tick_verde(0, NULL);
}

// Tick de VERDE: contagem, buzzer e transição
int64_t tick_verde(alarm_id_t id, void *ud) {
    if (estado_atual != VERDE) return 0;
    if (cnt_green > 0) {
        if (cnt_green <= 5) beep_short();
        update_display("Sinal: Verde", cnt_green);
        cnt_green--;
        alarm_green_tick = add_alarm_in_ms(1000, tick_verde, NULL, false);
    } else {
        fase_amarelo();
    }
    return 0;
}

// Inicia fase AMARELO
void fase_amarelo() {
    estado_atual = AMARELO;
    gpio_put(LED_VERDE,    1);
    gpio_put(LED_VERMELHO, 1);
    cnt_yellow = 3;
    tick_amarelo(0, NULL);
}

// Tick de AMARELO: contagem e transição para VERMELHO
int64_t tick_amarelo(alarm_id_t id, void *ud) {
    if (estado_atual != AMARELO) return 0;
    if (cnt_yellow > 0) {
        update_display("Sinal: Amarelo", cnt_yellow);
        cnt_yellow--;
        alarm_yellow_tick = add_alarm_in_ms(1000, tick_amarelo, NULL, false);
    } else {
        fase_vermelho();
    }
    return 0;
}

int main() {
    config_hw();
    printf("Semáforo Iniciado\n");
    fase_vermelho();
    while (1) tight_loop_contents();
    return 0;
}