#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "hardware/adc.h"
#include "hardware/dma.h"
#include "ssd1306.h"

#define NUM_SAMPLES 100      // número de amostras para a média

// pinos I2C do display
const uint I2C_SDA = 14;
const uint I2C_SCL = 15;

// buffer do display e área de renderização
uint8_t ssd[ssd1306_buffer_length];
struct render_area frame_area;

// buffer de ADC
uint16_t adc_buffer[NUM_SAMPLES];

// Função para desenhar texto com escala no SSD1306
void ssd1306_draw_string_scaled(uint8_t *buffer, int x, int y, const char *text, int scale) {
    while (*text) {
        for (int dx = 0; dx < scale; dx++) {
            for (int dy = 0; dy < scale; dy++) {
                ssd1306_draw_char(buffer, x + dx, y + dy, *text);
            }
        }
        x += 6 * scale;
        text++;
    }
}

// Converte valor bruto do ADC para temperatura em °C
float convert_to_celsius(uint16_t raw) {
    const float conversion_factor = 3.3f / (1 << 12); // 12 bits, referência 3.3 V
    float voltage = raw * conversion_factor;
    // fórmula do datasheet RP2040
    return 27.0f - (voltage - 0.706f) / 0.001721f;
}

int main() {
    stdio_init_all();
    sleep_ms(2000);  // aguarda estabilizar USB-Serial (se for usar printf)

    // --- Inicializa I2C e display ---
    i2c_init(i2c1, ssd1306_i2c_clock * 1000);
    gpio_set_function(I2C_SDA, GPIO_FUNC_I2C);
    gpio_set_function(I2C_SCL, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_SDA);
    gpio_pull_up(I2C_SCL);
    ssd1306_init();

    // Define área de renderização completa
    frame_area.start_column = 0;
    frame_area.end_column   = ssd1306_width - 1;
    frame_area.start_page   = 0;
    frame_area.end_page     = ssd1306_n_pages - 1;
    calculate_render_area_buffer_length(&frame_area);

    // --- Inicializa ADC interno ---
    adc_init();
    adc_set_temp_sensor_enabled(true);
    adc_select_input(4);  // canal 4 = sensor de temperatura

    // --- Configura canal DMA ---
    int dma_chan = dma_claim_unused_channel(true);
    dma_channel_config cfg = dma_channel_get_default_config(dma_chan);
    channel_config_set_transfer_data_size(&cfg, DMA_SIZE_16);
    channel_config_set_read_increment(&cfg, false);
    channel_config_set_write_increment(&cfg, true);
    channel_config_set_dreq(&cfg, DREQ_ADC);

    while (1) {
        // Prepara ADC FIFO e DMA
        adc_fifo_drain();
        adc_run(false);
        adc_fifo_setup(true, true, 1, false, false);
        adc_run(true);

        dma_channel_configure(
            dma_chan,
            &cfg,
            adc_buffer,            // destino: nosso buffer em RAM
            &adc_hw->fifo,         // origem: FIFO do ADC
            NUM_SAMPLES,           // quantas amostras
            true                   // inicia imediatamente
        );
        dma_channel_wait_for_finish_blocking(dma_chan);
        adc_run(false);

        // Calcula média das amostras
        float sum = 0;
        for (int i = 0; i < NUM_SAMPLES; i++) {
            sum += convert_to_celsius(adc_buffer[i]);
        }
        float avg_temp = sum / NUM_SAMPLES;

        // Prepara string para exibir
        char buf[32];
        snprintf(buf, sizeof(buf), "%.1f C", avg_temp);

        // Limpa buffer do display
        memset(ssd, 0, ssd1306_buffer_length);

        // Desenha temperatura centralizada e escalada
        int scale = 2;
        int txt_width  = strlen(buf) * 6 * scale;
        int txt_height = 8 * scale;
        int pos_x = (ssd1306_width - txt_width) / 2;
        int pos_y = ((ssd1306_n_pages * 8) - txt_height) / 2;
        ssd1306_draw_string_scaled(ssd, pos_x, pos_y, buf, scale);

        // Atualiza display
        render_on_display(ssd, &frame_area);

        sleep_ms(1000);
    }

    return 0;
}