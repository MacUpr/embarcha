#include "funcao_atividade_.h"
#include "funcoes_neopixel.h"

// Variáveis da fila e contador de eventos (mantidas do código original)
int fila[TAM_FILA];
int inicio = 0;
int fim = 0;
int quantidade = 0;
int contador = 0;

// Constantes para botões e LEDs (mantidas do código original)
absolute_time_t ultimo_toque[NUM_BOTOES];
const uint BOTOES[NUM_BOTOES] = {BOTAO_A, BOTAO_B, BOTAO_JOYSTICK};
const uint LEDS[NUM_BOTOES]   = {LED_VERMELHO, LED_AZUL, LED_VERDE};

// Variáveis de estado (mantidas do código original)
volatile bool eventos_pendentes[NUM_BOTOES] = {false, false, false};
volatile bool estado_leds[NUM_BOTOES] = {false, false, false};
volatile bool core1_pronto = false;

// Callback da interrupção GPIO (mantida do código original)
void gpio_callback(uint gpio, uint32_t events) {
    for (int i = 0; i < NUM_BOTOES; i++) {
        if (gpio == BOTOES[i] && (events & GPIO_IRQ_EDGE_FALL)) {
            multicore_fifo_push_blocking(i);  // sem desabilitar a interrupção
        }
    }
}

// Função para inicializar pinos (mantida do código original)
void inicializar_pino(uint pino, uint direcao, bool pull_up, bool pull_down) {
    gpio_init(pino);
    gpio_set_dir(pino, direcao);

    if (direcao == GPIO_IN) {
        if (pull_up) {
            gpio_pull_up(pino);
        } else if (pull_down) {
            gpio_pull_down(pino);
        } else {
            gpio_disable_pulls(pino);
        }
    }
}

// Função para tratar eventos dos LEDs e botões no Núcleo 1 (MODIFICADA)
void tratar_eventos_leds() {
    core1_pronto = true;

    while (true) {
        uint32_t id1 = multicore_fifo_pop_blocking();  // Aguarda botão pressionado

        sleep_ms(DEBOUNCE_MS); // Debounce

        // Confirma se ainda está pressionado
        if (!gpio_get(BOTOES[id1])) {
            // Verifica se outro botão também está pressionado → ignora se sim
            bool outro_pressionado = false;
            for (int i = 0; i < NUM_BOTOES; i++) {
                if (i != id1 && !gpio_get(BOTOES[i])) {
                    outro_pressionado = true;
                    break;
                }
            }
            if (outro_pressionado) {
                // Espera soltar todos os botões que estavam pressionados
                for (int i = 0; i < NUM_BOTOES; i++) {
                    if (!gpio_get(BOTOES[i])) {
                         while (!gpio_get(BOTOES[i])) tight_loop_contents();
                    }
                }
                continue;
            }

            // --- INÍCIO DA LÓGICA MODIFICADA ---
            if (id1 == 2) { // BOTÃO DO JOYSTICK (BOTOES[2] == BOTAO_JOYSTICK)
                printf("Botão do Joystick pressionado: Resetando sistema.\n");

                // Zera o contador de eventos [cite: 67]
                contador = 0;

                // Apaga toda a matriz de NeoPixel [cite: 67]
                npClear();
                npWrite();
                index_neo = 0; // Reseta o índice da NeoPixel

                // Zera a fila e seus contadores [cite: 69]
                inicio = 0;
                fim = 0;
                quantidade = 0;
                // Limpa o array da fila (opcional, mas bom para garantir)
                for(int i = 0; i < TAM_FILA; i++) {
                    fila[i] = 0;
                }
                imprimir_fila(); // Imprime a fila vazia

                // Atualiza LEDs RGB externos para indicar estado de reset (ex: LED Azul aceso)
                gpio_put(LED_VERMELHO, false);
                gpio_put(LED_AZUL, true); // Indica que a fila está vazia/resetada
                gpio_put(LED_VERDE, false);

            } else if (id1 == 0 && index_neo < LED_COUNT) {  // BOTÃO A → incrementa (lógica original)
                uint8_t r = numero_aleatorio(1, 255);
                uint8_t g = numero_aleatorio(1, 255);
                uint8_t b = numero_aleatorio(1, 255);
                npAcendeLED(index_neo, r, g, b);
                index_neo++;

                if (quantidade < TAM_FILA) {
                    fila[fim] = contador++; // Usa o contador global de eventos
                    fim = (fim + 1) % TAM_FILA;
                    quantidade++;
                    imprimir_fila();
                }
                 // Atualiza LEDs RGB externos
                gpio_put(LED_VERMELHO, (index_neo == LED_COUNT));
                gpio_put(LED_AZUL, (index_neo == 0));
                gpio_put(LED_VERDE, false);


            } else if (id1 == 1 && index_neo > 0) {   // BOTÃO B → decrementa (lógica original)
                index_neo--;
                npAcendeLED(index_neo, 0, 0, 0);  // apaga o LED

                if (quantidade > 0) {
                    // int valor = fila[inicio]; // O valor removido não é usado, então esta linha pode ser comentada ou removida.
                    inicio = (inicio + 1) % TAM_FILA;
                    quantidade--;
                    imprimir_fila();
                }
                 // Atualiza LEDs RGB externos
                gpio_put(LED_VERMELHO, (index_neo == LED_COUNT));
                gpio_put(LED_AZUL, (index_neo == 0));
                gpio_put(LED_VERDE, false);
            }
            // --- FIM DA LÓGICA MODIFICADA ---


            // Espera botão ser solto
            while (!gpio_get(BOTOES[id1])) {
                tight_loop_contents();
            }
        }
    }
}

// Função para imprimir a fila (mantida do código original)
void imprimir_fila() {
    printf("Fila [tam=%d, contador_eventos=%d]: ", quantidade, contador); // Adicionado contador ao print
    int i = inicio;
    for (int c = 0; c < quantidade; c++) {
        printf("%d ", fila[i]);
        i = (i + 1) % TAM_FILA;
    }
    printf("\n");
}