#ifndef EFEITO_CURVA_AR_H
#define EFEITO_CURVA_AR_H

#include <stdint.h>

void efeitoCurvaNeoPixel(uint8_t r, uint8_t g, uint8_t b, uint16_t delay_ms);

#endif