#include <stdio.h>
#include <stdlib.h>
#include "pico/stdlib.h"
#include "pico/time.h"      // Biblioteca para controle de tempo (debounce)
#include "hardware/gpio.h"    // Biblioteca para controle dos pinos e interrupções

// Seus includes de projeto
#include "neopixel_driver.h"
#include "numeros_neopixel.h"
#include "testes_cores.h"
#include "efeito_curva_ar.h"
// O include "efeitos.h" parece não existir no seu projeto, se der erro, remova-o.

/* =============================================================================
 * CONFIGURAÇÃO DA INTERRUPÇÃO DO BOTÃO
 * =============================================================================
 */

// O pino do Botão A na placa BitDogLab é o GPIO 2.
#define BTN_A_PIN 5

// Flag global para comunicar a interrupção ao loop principal.
// 'volatile' é essencial para que o compilador trate esta variável corretamente.
volatile bool g_botao_pressionado = false;

// Esta é a Rotina de Serviço de Interrupção (ISR).
// É chamada automaticamente pelo hardware da Pico quando o botão é pressionado.
void callback_interrupcao_btn(uint gpio, uint32_t events) {
    // Adiciona um "debounce" para evitar que um único clique seja lido várias vezes.
    static uint32_t tempo_ultimo_toque = 0;
    uint32_t tempo_atual = to_ms_since_boot(get_absolute_time());

    if (tempo_atual - tempo_ultimo_toque > 250) { // Ignora cliques por 250ms
        tempo_ultimo_toque = tempo_atual;
        g_botao_pressionado = true; // SINALIZA que o botão foi pressionado!
    }
}

// Função para organizar a inicialização do pino e da interrupção.
void configurar_interrupcao_botao() {
    gpio_init(BTN_A_PIN);
    gpio_set_dir(BTN_A_PIN, GPIO_IN);
    gpio_pull_up(BTN_A_PIN); // Habilita o resistor de pull-up interno.

    // Associa nossa função de callback à interrupção do pino BTN_A_PIN,
    // acionada na "borda de descida" (quando o botão é pressionado).
    gpio_set_irq_enabled_with_callback(BTN_A_PIN, GPIO_IRQ_EDGE_FALL, true, &callback_interrupcao_btn);
}

/* =============================================================================
 * LÓGICA PRINCIPAL DO PROGRAMA
 * =============================================================================
 */

// Função que sorteia um número inteiro no intervalo [min, max].
int sorteia_entre(int min, int max) {
    return rand() % (max - min + 1) + min;
}

// Função de inicialização do sistema.
void setup() {
    stdio_init_all();
    npInit(LED_PIN);
    srand(time_us_32()); // Define uma semente para a geração de números aleatórios

    configurar_interrupcao_botao(); // Chama a configuração da interrupção

    // Mostra um número inicial (ex: 1) para dar um feedback visual
    // de que a placa ligou e o programa está rodando.
    mostrar_numero_1();
}

// Loop principal do programa, agora orientado a eventos.
void loop() {
    // O loop agora só verifica se a flag foi acionada pela interrupção.
    if (g_botao_pressionado) {
        g_botao_pressionado = false; // "Consome" o evento, resetando a flag.

        // Se o botão foi pressionado, sorteia e mostra um novo número.
        int numero_sorteado = sorteia_entre(1, 6);

        // O 'switch' para mostrar o número é melhor aqui, ou na função que criamos
        // no passo anterior (mostra_numero). Vamos manter seu estilo original por enquanto.
        switch (numero_sorteado) {
            case 1: mostrar_numero_1(); break;
            case 2: mostrar_numero_2(); break;
            case 3: mostrar_numero_3(); break;
            case 4: mostrar_numero_4(); break;
            case 5: mostrar_numero_5(); break;
            case 6: mostrar_numero_6(); break;
        }
    }
    // Não há 'sleep_ms' aqui. O processador fica livre e eficiente.
}

// Função 'main'. Chama o setup uma vez e o loop para sempre.
int main() {
    setup();
    while (true) {
        loop();
    }
    return 0; // Esta linha nunca será alcançada.
}