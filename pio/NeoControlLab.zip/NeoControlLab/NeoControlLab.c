#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "neopixel_driver.h"
#include "testes_cores.h"
#include "efeitos.h"
#include "efeito_curva_ar.h"
#include "numeros_neopixel.h"
#include <time.h>
#include <stdlib.h>
#include "pico/time.h"

// Definições para o BitdogLab
#define BOTAO_A_PIN 5  // Pino do botão A no BitdogLab

// Variáveis de controle
volatile bool botao_pressionado = false;
volatile uint32_t ultimo_debounce = 0;
const uint32_t DEBOUNCE_TIME_MS = 200;  // Tempo de debounce em ms

// Função de callback para interrupção do botão A
void botao_a_callback(uint gpio, uint32_t events) {
    uint32_t tempo_atual = to_ms_since_boot(get_absolute_time());
    
    // Implementa debounce para evitar múltiplas ativações
    if (tempo_atual - ultimo_debounce > DEBOUNCE_TIME_MS) {
        if (events & GPIO_IRQ_EDGE_FALL) {  // Detecta borda de descida (botão pressionado)
            botao_pressionado = true;
            ultimo_debounce = tempo_atual;
            printf("Botão A pressionado! Iniciando geração de números...\n");
        }
    }
}

// Inicializa o sistema, matriz NeoPixel e configurações de interrupção
void setup() {
    stdio_init_all();
    sleep_ms(1000);  // Aguarda conexão USB
    
    // Inicializa matriz NeoPixel
    npInit(LED_PIN);
    
    // Configura o botão A
    gpio_init(BOTAO_A_PIN);
    gpio_set_dir(BOTAO_A_PIN, GPIO_IN);
    gpio_pull_up(BOTAO_A_PIN);  // Pull-up interno
    
    // Configura interrupção para o botão A
    gpio_set_irq_enabled_with_callback(BOTAO_A_PIN, GPIO_IRQ_EDGE_FALL, true, &botao_a_callback);
    
    // Semente para aleatoriedade
    srand(time_us_32());
    
    printf("Sistema inicializado. Pressione o botão A para gerar números aleatórios.\n");
}

// Sorteia número inteiro entre [min, max]
int sorteia_entre(int min, int max) {
    return rand() % (max - min + 1) + min;
}

// Exibe o número sorteado de 1 a 6
void mostrar_numero_sorteado(int numero) {
    switch (numero) {
        case 1: mostrar_numero_1(); break;
        case 2: mostrar_numero_2(); break;
        case 3: mostrar_numero_3(); break;
        case 4: mostrar_numero_4(); break;
        case 5: mostrar_numero_5(); break;
        case 6: mostrar_numero_6(); break;
        default: 
            printf("Número inválido: %d\n", numero);
            break;
    }
}

// Executa a sequência de números aleatórios
void executar_sequencia_numeros() {
    // Limpa a matriz antes de iniciar
    npClear();
    npWrite();
    sleep_ms(100);
    
    int vezes = sorteia_entre(10, 50);  // Entre 10 e 50 execuções
    printf("Mostrando %d números aleatórios...\n", vezes);

    for (int i = 0; i < vezes; i++) {
        int n = sorteia_entre(1, 6);
        printf("Número sorteado: %d\n", n);
        mostrar_numero_sorteado(n);
        sleep_ms(100);  // Delay entre números
        
        // Verifica se outro botão foi pressionado durante a execução
        if (botao_pressionado) {
            botao_pressionado = false;  // Reset da flag
            printf("Nova sequência iniciada!\n");
            i = 0;  // Reinicia a sequência
            vezes = sorteia_entre(10, 50);  // Nova quantidade
        }
    }
    
    // Limpa a matriz ao final da sequência
    npClear();
    npWrite();
    printf("Sequência finalizada. Pressione o botão A novamente para uma nova sequência.\n");
}

// Efeito de espera visual (opcional)
void efeito_espera() {
    static int contador = 0;
    static bool direcao = true;
    
    // Efeito de "respiração" suave
    int intensidade = contador * 2;
    
    if (direcao) {
        contador++;
        if (contador >= 40) direcao = false;
    } else {
        contador--;
        if (contador <= 0) direcao = true;
    }
    
    // Acende apenas o LED central com intensidade variável
    npClear();
    npSetLED(12, intensidade/4, intensidade/8, intensidade/2); // LED central com cor suave
    npWrite();
}

int main() {
    setup();
    
    // Loop principal
    while (true) {
        // Verifica se o botão foi pressionado
        if (botao_pressionado) {
            botao_pressionado = false;  // Reset da flag
            executar_sequencia_numeros();
        }
        
        // Efeito visual de espera (opcional)
        efeito_espera();
        sleep_ms(50);  // Pequeno delay para não sobrecarregar o processador
    }
    
    return 0;
}