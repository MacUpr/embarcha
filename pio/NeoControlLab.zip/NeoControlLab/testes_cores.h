#ifndef TESTE_CORES_H
#define TESTE_CORES_H

void preencher_matriz_com_cores(void);
void testar_fileiras_colunas(void);


#endif