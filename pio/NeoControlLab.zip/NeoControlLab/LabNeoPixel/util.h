#ifndef UTIL_H
#define UTIL_H

void inicializar_aleatorio(void);
int numero_aleatorio(int min, int max);
float numero_aleatorio_0a1(void);

#endif