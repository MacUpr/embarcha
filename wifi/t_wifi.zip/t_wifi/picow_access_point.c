/**
 * Projeto: Simulador Portátil de Alarme para BitDogLab
 * Arquivo Principal: picow_access_point.c (ou nome de sua preferência)
 * Descrição: Versão corrigida e completa, combinando a robustez de rede
 * do picow_access_point.c original com a manipulação de display e periféricos
 * do lcd_oled_HelloWorld.c fornecido pelo usuário, e os requisitos do PDF.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h> // Para calloc

// Includes do Pico SDK e lwIP
#include "pico/stdlib.h"
#include "pico/cyw43_arch.h" // Para Wi-Fi
#include "lwip/pbuf.h"
#include "lwip/tcp.h"

// Para Servidor DHCP e DNS (do exemplo picow_access_point)
#include "dhcpserver.h" // [cite: 40]
#include "dnsserver.h"  // [cite: 40]

// Para Hardware I2C e Display OLED
#include "hardware/i2c.h"   // [cite: 2]
#include "ssd1306.h"      // Sua biblioteca OLED

// --- Definições de Pinos (Conforme BitDogLab e seu lcd_oled_HelloWorld.c) ---
const uint ALARM_LED_PIN = 13;     // LED Vermelho para alarme
const uint BUZZER_PIN = 10;    // Buzzer B
const uint OLED_SDA_PIN = 14;  // I2C_SDA para Display OLED
const uint OLED_SCL_PIN = 15;  // I2C_SCL para Display OLED
#define I2C_PORT_OLED i2c1     // Display OLED usa i2c1 nestes pinos

// --- Configurações do Access Point ---
#define WIFI_AP_SSID "AlarmeBitDogLabWiFi" // Nome da rede Wi-Fi do simulador
#define WIFI_AP_PASSWORD "BitDogL@b123"    // Senha da rede

// --- Constantes do Servidor HTTP (do exemplo picow_access_point.c) ---
#define HTTP_SERVER_PORT 80
#define DEBUG_printf printf 
#define HTTP_METHOD_GET "GET"
#define HTTP_RESPONSE_HTML_HEADERS "HTTP/1.1 200 OK\nContent-Length: %d\nContent-Type: text/html; charset=utf-8\nConnection: close\n\n"
#define TCP_POLL_TIME_S 5

// --- URLs para controle do alarme (do PDF da tarefa) ---
#define ALARM_PATH_ON "/ligar"    
#define ALARM_PATH_OFF "/desligar"  

// --- Constantes para Lógica Não-Bloqueante (do PDF da tarefa) ---
#define ALARM_BLINK_INTERVAL_MS 500 

// --- Variáveis Globais para Display OLED (do seu exemplo lcd_oled_HelloWorld.c) ---
uint8_t global_ssd_buffer[ssd1306_buffer_length]; // Buffer global para o display
struct render_area global_oled_frame_area;      // Área de renderização global

// --- Estruturas de Estado TCP (do exemplo picow_access_point.c) ---
// Estado global do servidor (inclui estado do alarme)
typedef struct TCP_ALARM_SERVER_STATE_T_ {
    struct tcp_pcb *server_tcp_pcb;
    bool server_complete_flag;
    ip_addr_t gateway_ip;
    // Estado específico do sistema de alarme
    bool alarm_system_active;
    absolute_time_t next_alarm_blink_time;
    bool current_led_blink_state;
} TCP_ALARM_SERVER_STATE_T;

// Estado de uma conexão de cliente individual
typedef struct TCP_CLIENT_CONNECTION_STATE_T_ {
    struct tcp_pcb *client_tcp_pcb;
    int data_sent_length;
    char http_headers_buffer[128];    
    char html_response_buffer[512]; 
    int http_header_length;
    int html_content_length;
    TCP_ALARM_SERVER_STATE_T *global_server_state_ptr; 
} TCP_CLIENT_CONNECTION_STATE_T;


// --- Função para desenhar string com escala (COPIADA de lcd_oled_HelloWorld.c que você forneceu) ---
//
// Esta função usa `ssd1306_draw_char` da sua biblioteca ssd1306.h/ssd1306_i2c.c
// A `ssd1306_draw_char` da sua biblioteca desenha um caractere da fonte bitmap (8 pixels de largura).
// A "escala" aqui afeta principalmente o espaçamento e a repetição do caractere base.
void users_ssd1306_draw_string_scaled(uint8_t *buffer, int x, int y, const char *text, int scale) {
    int start_x_char = x; // Posição x inicial para o caractere atual
    while (*text) {
        // A lógica de escala do seu exemplo original lcd_oled_HelloWorld.c.
        // Se scale = 1, desenha o caractere uma vez.
        // Se scale > 1, a intenção do seu exemplo original era preencher uma área maior.
        // Para cada caractere do texto, desenhamos na posição correta.
        // A função ssd1306_draw_char da sua biblioteca é chamada uma vez por caractere de `text`.
        ssd1306_draw_char(buffer, start_x_char, y, *text); // (chamada com 4 argumentos)
        
        start_x_char += 6 * scale; // Avança para a posição do próximo caractere
                                   // (6 pixels = 5 de largura da fonte + 1 de espaço, vezes a escala para espaçamento)
        text++;
    }
}


// --- Protótipos das Funções TCP e de Lógica ---
static err_t app_tcp_close_client_connection(TCP_CLIENT_CONNECTION_STATE_T *client_state, struct tcp_pcb *client_pcb, err_t close_reason);
static void app_tcp_server_close_main(TCP_ALARM_SERVER_STATE_T *server_state);
static err_t app_tcp_data_sent_callback(void *arg, struct tcp_pcb *pcb, u16_t len);
static int app_http_page_handler(TCP_ALARM_SERVER_STATE_T *server_state, const char *request_path, char *html_buffer, size_t buffer_len);
static err_t app_tcp_receive_callback(void *arg, struct tcp_pcb *pcb, struct pbuf *p_buffer, err_t err_status);
static err_t app_tcp_poll_client_connection(void *arg, struct tcp_pcb *pcb);
static void app_tcp_error_callback(void *arg, err_t err_status);
static err_t app_tcp_accept_new_connection(void *arg, struct tcp_pcb *new_client_pcb, err_t err_status);
static bool app_tcp_server_start(void *arg_server_state, const char *ap_name);
void app_pico_key_pressed_callback(void *param_server_state); 
void app_init_hardware_and_state(TCP_ALARM_SERVER_STATE_T *server_state);
void app_run_periodic_alarm_tasks(TCP_ALARM_SERVER_STATE_T *server_state);


// --- Implementação das Funções ---

void app_init_hardware_and_state(TCP_ALARM_SERVER_STATE_T *server_state) {
    // 1. Inicializa Pinos de LED e Buzzer
    gpio_init(ALARM_LED_PIN); //
    gpio_set_dir(ALARM_LED_PIN, GPIO_OUT); //
    gpio_put(ALARM_LED_PIN, 0); 

    gpio_init(BUZZER_PIN); //
    gpio_set_dir(BUZZER_PIN, GPIO_OUT); //
    gpio_put(BUZZER_PIN, 0); 

    // 2. Inicializa I2C e Display OLED
    uint32_t i2c_actual_baudrate = i2c_init(I2C_PORT_OLED, ssd1306_i2c_clock * 1000); //
    DEBUG_printf("I2C for OLED initialized at %d Hz on i2c1\n", i2c_actual_baudrate);
    gpio_set_function(OLED_SDA_PIN, GPIO_FUNC_I2C); //
    gpio_set_function(OLED_SCL_PIN, GPIO_FUNC_I2C); //
    gpio_pull_up(OLED_SDA_PIN); //
    gpio_pull_up(OLED_SCL_PIN); //

    ssd1306_init(); //

    global_oled_frame_area.start_column = 0; //
    global_oled_frame_area.end_column = ssd1306_width - 1; //
    global_oled_frame_area.start_page = 0; //
    global_oled_frame_area.end_page = ssd1306_n_pages - 1; //
    calculate_render_area_buffer_length(&global_oled_frame_area); //

    // 3. Configura estado inicial do alarme
    server_state->alarm_system_active = false;
    server_state->current_led_blink_state = false;
    server_state->next_alarm_blink_time = get_absolute_time();

    // 4. Exibe mensagem inicial no OLED ("Sistema em repouso")
    memset(global_ssd_buffer, 0, ssd1306_buffer_length); //
    const char *initial_msg_line1 = "Sistema em"; 
    const char *initial_msg_line2 = "repouso";    
    int x1 = (ssd1306_width - (strlen(initial_msg_line1) * 6 * 1)) / 2; // Escala 1 para espaçamento (fonte é 8px da lib)
    int y1 = 15; 
    int x2 = (ssd1306_width - (strlen(initial_msg_line2) * 6 * 1)) / 2; // Escala 1 para espaçamento
    int y2 = 35; 
    if (x1 < 0) x1 = 0;
    if (x2 < 0) x2 = 0;
    users_ssd1306_draw_string_scaled(global_ssd_buffer, x1, y1, initial_msg_line1, 1);
    users_ssd1306_draw_string_scaled(global_ssd_buffer, x2, y2, initial_msg_line2, 1);
    render_on_display(global_ssd_buffer, &global_oled_frame_area); //
}

void app_run_periodic_alarm_tasks(TCP_ALARM_SERVER_STATE_T *server_state) {
    if (!server_state->alarm_system_active) {
        if (server_state->current_led_blink_state) { 
            gpio_put(ALARM_LED_PIN, 0);
            gpio_put(BUZZER_PIN, 0);
            server_state->current_led_blink_state = false;
        }
        return;
    }

    if (absolute_time_diff_us(get_absolute_time(), server_state->next_alarm_blink_time) < 0) {
        server_state->current_led_blink_state = !server_state->current_led_blink_state;
        gpio_put(ALARM_LED_PIN, server_state->current_led_blink_state); 
        gpio_put(BUZZER_PIN, server_state->current_led_blink_state);   
        server_state->next_alarm_blink_time = make_timeout_time_ms(ALARM_BLINK_INTERVAL_MS);
    }
}

// --- Funções TCP (Baseadas em picow_access_point.c) ---
static err_t app_tcp_close_client_connection(TCP_CLIENT_CONNECTION_STATE_T *client_state, struct tcp_pcb *client_pcb, err_t close_reason) {
    if (client_pcb) {
        assert(client_state && client_state->client_tcp_pcb == client_pcb);
        tcp_arg(client_pcb, NULL);
        tcp_poll(client_pcb, NULL, 0);
        tcp_sent(client_pcb, NULL);
        tcp_recv(client_pcb, NULL);
        tcp_err(client_pcb, NULL);
        err_t err = tcp_close(client_pcb);
        if (err != ERR_OK) {
            DEBUG_printf("TCP close failed %d, calling abort\n", err);
            tcp_abort(client_pcb);
            close_reason = ERR_ABRT;
        }
        if (client_state) {
            free(client_state);
        }
    }
    return close_reason;
}

static void app_tcp_server_close_main(TCP_ALARM_SERVER_STATE_T *server_state) {
    if (server_state->server_tcp_pcb) {
        tcp_arg(server_state->server_tcp_pcb, NULL);
        tcp_close(server_state->server_tcp_pcb);
        server_state->server_tcp_pcb = NULL;
    }
}

static err_t app_tcp_data_sent_callback(void *arg, struct tcp_pcb *pcb, u16_t len) {
    TCP_CLIENT_CONNECTION_STATE_T *client_state = (TCP_CLIENT_CONNECTION_STATE_T*)arg;
    DEBUG_printf("TCP data sent: %u bytes\n", len);
    client_state->data_sent_length += len;
    if (client_state->data_sent_length >= client_state->http_header_length + client_state->html_content_length) {
        DEBUG_printf("All data sent, closing connection.\n");
        return app_tcp_close_client_connection(client_state, pcb, ERR_OK);
    }
    return ERR_OK;
}

static int app_http_page_handler(TCP_ALARM_SERVER_STATE_T *server_state, const char *request_path, char *html_buffer, size_t buffer_len) {
    if (request_path) {
        if (strncmp(request_path, ALARM_PATH_ON, strlen(ALARM_PATH_ON)) == 0) {
            if (!server_state->alarm_system_active) {
                server_state->alarm_system_active = true;
                DEBUG_printf("Alarme ATIVADO via HTTP\n");
            }
        } else if (strncmp(request_path, ALARM_PATH_OFF, strlen(ALARM_PATH_OFF)) == 0) {
            if (server_state->alarm_system_active) {
                server_state->alarm_system_active = false;
                DEBUG_printf("Alarme DESATIVADO via HTTP\n");
                gpio_put(ALARM_LED_PIN, 0);
                gpio_put(BUZZER_PIN, 0);
                server_state->current_led_blink_state = false; 
            }
        }
    }

    memset(global_ssd_buffer, 0, ssd1306_buffer_length); //
    if (server_state->alarm_system_active) {
        const char *alarm_msg = "EVACUAR"; 
        int text_width = strlen(alarm_msg) * 6 * 2; // Espaçamento com "escala" 2 (fonte da lib é 8px)
        int x_evac = (ssd1306_width - text_width) / 2;
        if (x_evac < 0) x_evac = 0;
        users_ssd1306_draw_string_scaled(global_ssd_buffer, x_evac, 25, alarm_msg, 2); // Usando a função copiada
    } else {
        const char *msg1 = "Sistema em";
        const char *msg2 = "repouso";
        int x1 = (ssd1306_width - (strlen(msg1) * 6 * 1)) / 2; // Escala 1
        int y1 = 15;
        int x2 = (ssd1306_width - (strlen(msg2) * 6 * 1)) / 2; // Escala 1
        int y2 = 35;
        if (x1 < 0) x1 = 0;
        if (x2 < 0) x2 = 0;
        users_ssd1306_draw_string_scaled(global_ssd_buffer, x1, y1, msg1, 1);
        users_ssd1306_draw_string_scaled(global_ssd_buffer, x2, y2, msg2, 1);
    }
    render_on_display(global_ssd_buffer, &global_oled_frame_area); //

    const char *current_alarm_status_text = server_state->alarm_system_active ?
        "<strong style='color:red;'>ATIVADO</strong>" :
        "<strong style='color:green;'>DESATIVADO</strong>";
    
    return snprintf(html_buffer, buffer_len,
                    "<!DOCTYPE html><html><head><title>Controle de Alarme BitDogLab</title>"
                    "<meta name='viewport' content='width=device-width, initial-scale=1'>"
                    "<style>"
                    "body{font-family:Arial,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:90vh;margin:0;background-color:#f0f2f5;color:#333;text-align:center;padding:10px;}"
                    "h1{color:#2c3e50;margin-bottom:20px;}"
                    "p{font-size:1.2em;margin-bottom:30px;}"
                    ".status-box{padding:10px 20px;border-radius:8px;font-size:1.1em;margin-bottom:30px;display:inline-block;}"
                    ".status-box strong{font-size:1.2em;}"
                    ".btn-container{display:flex;flex-direction:column;gap:15px;width:100%%;max-width:320px;}"
                    "a.btn{display:block;text-decoration:none;color:white;padding:15px 25px;border-radius:8px;font-size:1.3em;font-weight:bold;box-shadow:0 4px 6px rgba(0,0,0,0.1);transition:all 0.2s ease-in-out;}"
                    "a.btn:active{transform:translateY(2px);box-shadow:0 2px 3px rgba(0,0,0,0.15);}"
                    "a.btn-on{background-color:#e74c3c;border-bottom:4px solid #c0392b;}a.btn-on:hover{background-color:#c0392b;}"
                    "a.btn-off{background-color:#2ecc71;border-bottom:4px solid #27ae60;}a.btn-off:hover{background-color:#27ae60;}"
                    "</style></head>"
                    "<body><h1>Simulador de Alarme Port&aacute;til</h1>"
                    "<div class='status-box'><p>Estado Atual: %s</p></div>"
                    "<div class='btn-container'>"
                    "<a href='%s' class='btn btn-on'>ATIVAR ALARME</a>"
                    "<a href='%s' class='btn btn-off'>DESATIVAR ALARME</a>"
                    "</div></body></html>",
                    current_alarm_status_text, ALARM_PATH_ON, ALARM_PATH_OFF);
}

static err_t app_tcp_receive_callback(void *arg, struct tcp_pcb *pcb, struct pbuf *p_buffer, err_t err_status) {
    TCP_CLIENT_CONNECTION_STATE_T *client_state = (TCP_CLIENT_CONNECTION_STATE_T*)arg;

    if (!p_buffer) { 
        DEBUG_printf("Client closed connection (p_buffer is NULL).\n");
        return app_tcp_close_client_connection(client_state, pcb, ERR_OK);
    }
    assert(client_state && client_state->client_tcp_pcb == pcb && client_state->global_server_state_ptr);

    if (p_buffer->tot_len > 0) {
        DEBUG_printf("Data received: %d bytes, error: %d\n", p_buffer->tot_len, err_status);
        pbuf_copy_partial(p_buffer, client_state->http_headers_buffer,
                          p_buffer->tot_len > sizeof(client_state->http_headers_buffer) - 1 ? sizeof(client_state->http_headers_buffer) - 1 : p_buffer->tot_len,
                          0);
        client_state->http_headers_buffer[p_buffer->tot_len < sizeof(client_state->http_headers_buffer) ? p_buffer->tot_len : sizeof(client_state->http_headers_buffer) - 1] = '\0';

        if (strncmp(HTTP_METHOD_GET, client_state->http_headers_buffer, strlen(HTTP_METHOD_GET)) == 0) {
            char *request_path_start = client_state->http_headers_buffer + strlen(HTTP_METHOD_GET);
            while (*request_path_start == ' ' && *request_path_start != '\0') request_path_start++; 

            char *path_end_space = strchr(request_path_start, ' ');
            if (path_end_space) {
                *path_end_space = '\0'; 
            }
            DEBUG_printf("HTTP Request Path: \"%s\"\n", request_path_start);

            client_state->html_content_length = app_http_page_handler(client_state->global_server_state_ptr,
                                                                    request_path_start,
                                                                    client_state->html_response_buffer,
                                                                    sizeof(client_state->html_response_buffer));
            
            if (client_state->html_content_length < 0 || client_state->html_content_length >= sizeof(client_state->html_response_buffer) -1) {
                DEBUG_printf("HTML content generation error or buffer too small.\n");
                tcp_recved(pcb, p_buffer->tot_len);
                pbuf_free(p_buffer);
                return app_tcp_close_client_connection(client_state, pcb, ERR_CLSD);
            }

            client_state->http_header_length = snprintf(client_state->http_headers_buffer, sizeof(client_state->http_headers_buffer),
                                                        HTTP_RESPONSE_HTML_HEADERS, client_state->html_content_length);
            if (client_state->http_header_length >= sizeof(client_state->http_headers_buffer) -1) {
                DEBUG_printf("HTTP headers buffer too small.\n");
                tcp_recved(pcb, p_buffer->tot_len);
                pbuf_free(p_buffer);
                return app_tcp_close_client_connection(client_state, pcb, ERR_CLSD);
            }
            
            client_state->data_sent_length = 0; 
            err_t write_err = tcp_write(pcb, client_state->http_headers_buffer, client_state->http_header_length, TCP_WRITE_FLAG_COPY);
            if (write_err != ERR_OK) {
                DEBUG_printf("TCP write failed for headers: %d\n", write_err);
                tcp_recved(pcb, p_buffer->tot_len);
                pbuf_free(p_buffer);
                return app_tcp_close_client_connection(client_state, pcb, write_err);
            }

            if (client_state->html_content_length > 0) {
                write_err = tcp_write(pcb, client_state->html_response_buffer, client_state->html_content_length, TCP_WRITE_FLAG_COPY);
                if (write_err != ERR_OK) {
                    DEBUG_printf("TCP write failed for HTML body: %d\n", write_err);
                    tcp_recved(pcb, p_buffer->tot_len);
                    pbuf_free(p_buffer);
                    return app_tcp_close_client_connection(client_state, pcb, write_err);
                }
            }
            tcp_output(pcb); 
        }
        tcp_recved(pcb, p_buffer->tot_len); 
    }
    pbuf_free(p_buffer); 
    return ERR_OK;
}

static err_t app_tcp_poll_client_connection(void *arg, struct tcp_pcb *pcb) {
    TCP_CLIENT_CONNECTION_STATE_T *client_state = (TCP_CLIENT_CONNECTION_STATE_T*)arg;
    DEBUG_printf("TCP poll: No activity, closing inactive connection.\n");
    return app_tcp_close_client_connection(client_state, pcb, ERR_OK); 
}

static void app_tcp_error_callback(void *arg, err_t err_status) {
    TCP_CLIENT_CONNECTION_STATE_T *client_state = (TCP_CLIENT_CONNECTION_STATE_T*)arg;
    if (err_status != ERR_ABRT) { 
        DEBUG_printf("TCP error callback: err %d\n", err_status);
    }
    if (client_state) {
        if (client_state->client_tcp_pcb) {
           tcp_arg(client_state->client_tcp_pcb, NULL); 
        }
        DEBUG_printf("Freeing client state due to TCP error.\n");
        free(client_state);
    }
}

static err_t app_tcp_accept_new_connection(void *arg, struct tcp_pcb *new_client_pcb, err_t err_status) {
    TCP_ALARM_SERVER_STATE_T *global_server_state = (TCP_ALARM_SERVER_STATE_T*)arg; 
    if (err_status != ERR_OK || new_client_pcb == NULL) {
        DEBUG_printf("TCP accept failed, err: %d\n", err_status);
        return ERR_VAL;
    }
    DEBUG_printf("New client connection accepted.\n");

    TCP_CLIENT_CONNECTION_STATE_T *client_specific_state = calloc(1, sizeof(TCP_CLIENT_CONNECTION_STATE_T));
    if (!client_specific_state) {
        DEBUG_printf("Failed to allocate memory for client connection state.\n");
        tcp_close(new_client_pcb); 
        return ERR_MEM;
    }
    client_specific_state->client_tcp_pcb = new_client_pcb;
    client_specific_state->global_server_state_ptr = global_server_state; 

    tcp_arg(new_client_pcb, client_specific_state); 
    tcp_sent(new_client_pcb, app_tcp_data_sent_callback);
    tcp_recv(new_client_pcb, app_tcp_receive_callback);
    tcp_poll(new_client_pcb, app_tcp_poll_client_connection, TCP_POLL_TIME_S * 2); 
    tcp_err(new_client_pcb, app_tcp_error_callback);

    return ERR_OK;
}

static bool app_tcp_server_start(void *arg_server_state, const char *ap_name) {
    TCP_ALARM_SERVER_STATE_T *server_state = (TCP_ALARM_SERVER_STATE_T*)arg_server_state;
    DEBUG_printf("Starting TCP server on port %d for AP '%s'\n", HTTP_SERVER_PORT, ap_name);

    struct tcp_pcb *main_pcb = tcp_new_ip_type(IPADDR_TYPE_ANY); 
    if (!main_pcb) {
        DEBUG_printf("Failed to create main TCP PCB.\n");
        return false;
    }

    err_t bind_err = tcp_bind(main_pcb, IP_ANY_TYPE, HTTP_SERVER_PORT); 
    if (bind_err != ERR_OK) {
        DEBUG_printf("Failed to bind TCP server to port %d, error: %d\n", HTTP_SERVER_PORT, bind_err);
        tcp_close(main_pcb); 
        return false;
    }

    server_state->server_tcp_pcb = tcp_listen_with_backlog(main_pcb, 1); 
    if (!server_state->server_tcp_pcb) {
        DEBUG_printf("Failed to listen on TCP server.\n");
        if (main_pcb) {
            tcp_close(main_pcb);
        }
        return false;
    }

    tcp_arg(server_state->server_tcp_pcb, server_state); 
    tcp_accept(server_state->server_tcp_pcb, app_tcp_accept_new_connection); 

    DEBUG_printf("TCP Server listening. SSID: '%s', IP: %s\n", ap_name, ip4addr_ntoa(&server_state->gateway_ip));
    DEBUG_printf("Access Web Interface or press 'd' in serial console to stop.\n");
    return true;
}

void app_pico_key_pressed_callback(void *param_server_state) {
    assert(param_server_state);
    TCP_ALARM_SERVER_STATE_T *server_state = (TCP_ALARM_SERVER_STATE_T*)param_server_state;
    int received_char = getchar_timeout_us(0);
    if (received_char == 'd' || received_char == 'D') {
        DEBUG_printf("Key 'd' pressed, disabling AP mode and exiting...\n");
        cyw43_arch_disable_ap_mode();
        server_state->server_complete_flag = true; 
    }
}

// --- Função `main` ---
int main() {
    stdio_init_all(); 
    DEBUG_printf("Simulador de Alarme Portatil para BitDogLab - Iniciando...\n");

    TCP_ALARM_SERVER_STATE_T *alarm_server_global_state = calloc(1, sizeof(TCP_ALARM_SERVER_STATE_T));
    if (!alarm_server_global_state) {
        DEBUG_printf("ERRO CRITICO: Falha ao alocar memoria para o estado do servidor.\n");
        return 1;
    }

    if (cyw43_arch_init()) {
        DEBUG_printf("ERRO CRITICO: Falha ao inicializar a arquitetura Wi-Fi (cyw43_arch_init).\n");
        free(alarm_server_global_state);
        return 1;
    }
    DEBUG_printf("Wi-Fi Arch inicializado.\n");

    app_init_hardware_and_state(alarm_server_global_state);
    DEBUG_printf("Hardware e estado do alarme inicializados.\n");

    stdio_set_chars_available_callback(app_pico_key_pressed_callback, alarm_server_global_state);

    cyw43_arch_enable_ap_mode(WIFI_AP_SSID, WIFI_AP_PASSWORD, CYW43_AUTH_WPA2_AES_PSK);
    DEBUG_printf("Modo Access Point ativado: SSID='%s'\n", WIFI_AP_SSID);

    // Correção da inicialização do IP e Máscara
    alarm_server_global_state->gateway_ip.addr = CYW43_DEFAULT_IP_AP_ADDRESS; // Definido pelo CMakeLists.txt
    ip_addr_t network_mask;
    network_mask.addr = PP_HTONL(0xFFFFFF00UL); // 255.255.255.0
    
    dhcp_server_t dhcp_server_instance;
    dhcp_server_init(&dhcp_server_instance, &alarm_server_global_state->gateway_ip, &network_mask); // [cite: 40]
    DEBUG_printf("Servidor DHCP inicializado.\n");

    dns_server_t dns_server_instance;
    dns_server_init(&dns_server_instance, &alarm_server_global_state->gateway_ip); // [cite: 40]
    DEBUG_printf("Servidor DNS inicializado.\n");

    if (!app_tcp_server_start(alarm_server_global_state, WIFI_AP_SSID)) {
        DEBUG_printf("ERRO CRITICO: Falha ao iniciar o servidor TCP.\n");
        dns_server_deinit(&dns_server_instance);
        dhcp_server_deinit(&dhcp_server_instance);
        cyw43_arch_deinit();
        free(alarm_server_global_state);
        return 1;
    }

    alarm_server_global_state->server_complete_flag = false;
    DEBUG_printf("Sistema de Alarme pronto e rodando!\n");

    while (!alarm_server_global_state->server_complete_flag) {
        #if PICO_CYW43_ARCH_POLL 
        cyw43_arch_poll();
        cyw43_arch_wait_for_work_until(make_timeout_time_ms(50)); 
        #else 
        sleep_ms(20); 
        #endif
        
        app_run_periodic_alarm_tasks(alarm_server_global_state);
    }

    DEBUG_printf("Finalizando o sistema de alarme...\n");
    app_tcp_server_close_main(alarm_server_global_state); 
    dns_server_deinit(&dns_server_instance);      
    dhcp_server_deinit(&dhcp_server_instance);    
    cyw43_arch_deinit(); 
    free(alarm_server_global_state); 
    DEBUG_printf("Sistema finalizado. Ate mais!\n");
    return 0;
}